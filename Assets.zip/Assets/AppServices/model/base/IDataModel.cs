﻿namespace Unity3dAzure.AppServices
{
    public interface IDataModel
    {
        string GetId();
    }
}