﻿namespace Unity3dAzure.AppServices
{
    public class ResponseError
    {
		public int code { get; set; }
		public string error { get; set; }
    }
}