﻿using System.Collections;
using System.Collections.Generic;
using System;
using RestSharp;

namespace Unity3dAzure.AppServices
{
	/// <summary>
	/// Interface to support table Query with `$inlinecount=allpages` 
	/// </summary>
	public interface INestedResults
	{
	}
}