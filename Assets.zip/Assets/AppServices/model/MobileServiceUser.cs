﻿namespace Unity3dAzure.AppServices
{
    public class MobileServiceUser
    {
        public string authenticationToken { get; set; }
        public User user { get; set; }
    }
}