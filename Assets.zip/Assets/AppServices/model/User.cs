﻿namespace Unity3dAzure.AppServices
{
    public class User
    {
        public string userId { get; set; }
    }
}